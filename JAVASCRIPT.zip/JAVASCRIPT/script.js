function updateDateTime() {
  const currentDate = new Date();
  const date = currentDate.toLocaleDateString();
  const time = currentDate.toLocaleTimeString();
  
  document.getElementById("footer-info").innerText = `Current date: ${date} | Time: ${time}`;
}

updateDateTime();
setInterval(updateDateTime, 1000);